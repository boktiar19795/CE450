def sum_odd():
    n = input("Enter a number: ")
    if n.lstrip('-').isdigit():  # Check if input is a positive or negative integer
        n = int(n)
        result = 0
        if n >= 0:
            for i in range(1, n + 1, 2):
                result += i
        else:
            for i in range(-1, n - 1, -2):
                result += i
        return result
    else:
        return "Please enter a valid number."

print(sum_odd())
