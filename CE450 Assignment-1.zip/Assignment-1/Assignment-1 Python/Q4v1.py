def df():
    try:
        x = int(input("Enter the first number: "))
        y = int(input("Enter the second number: "))
        z = int(input("Enter the third number: "))
    except ValueError:
        print("Please enter valid integers.")
        return False

    if x - y == z or y - x == z:
        print(f"{x} - {y} is {z}")
        return True
    elif x - z == y or z - x == y:
        print(f"{x} - {z} is {y}")
        return True
    elif y - z == x or z - y == x:
        print(f"{y} - {z} is {x}")
        return True
    else:
        return False

print(df())
