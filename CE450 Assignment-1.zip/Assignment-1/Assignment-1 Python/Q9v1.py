def uniq_digits(x):
    if isinstance(x, int) and x < 0:
        print(f"{x}: Invalid input")
        return 0
    elif isinstance(x, str):
        print(f"{x}: Invalid input")
        return 0

    digits = sorted(set(str(x)))
    num_unique_digits = len(digits)
    output = f"{x}: {', '.join(digits)}"
    output += "" if num_unique_digits != len(str(x)) else "\nAll are unique"
    print(output)
    return num_unique_digits

# Test cases
print("Enter the numbers:")
numbers = input().split()
print("The output is:")
for number in numbers:
    uniq_digits(int(number) if number.isdigit() else number)
