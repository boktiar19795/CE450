def factors(m):
    factors_list = []
    if m <= 1:
        return "Please enter an integer greater than 1."
    for i in range(1, abs(m) + 1):
        if m % i == 0:
            factors_list.append(i)
    return factors_list


def get_input_value(prompt):
    while True:
        try:
            value = int(input(prompt))
            return value
        except ValueError:
            print("Please enter a valid integer.")


m = get_input_value("Enter an integer greater than 1: ")

result = factors(m)

if isinstance(result, list):
    largest_factor = result[-1]
    print("The largest factor of", m, "is:", largest_factor)
    print("All factors of", m, "are:", result)
else:
    print(result)
