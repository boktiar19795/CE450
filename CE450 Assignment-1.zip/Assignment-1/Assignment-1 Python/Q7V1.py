def same_ord(a, b):
    return len(str(a)) == len(str(b))

def get_integer_input(prompt):
    while True:
        value = input(prompt)
        if value.isdigit():
            return int(value)
        else:
            print("Invalid input. Please enter a valid positive integer.")

# Prompt the user for input
a = get_integer_input("Enter the first number: ")
b = get_integer_input("Enter the second number: ")

if a <= 0 or b <= 0:
    print("Invalid input. Please enter positive integers.")
else:
    result = same_ord(a, b)
    print(result)
