def amc(n):
    if isinstance(n, int) and n < 0:
        return "Invalid input"
    elif isinstance(n, str):
        return "Invalid input"

    def sum_proper_divisors(m):
        divisors = [1]
        for i in range(2, int(m ** 0.5) + 1):
            if m % i == 0:
                divisors.append(i)
                if i != m // i:
                    divisors.append(m // i)
        return sum(divisors)

    m = n + 1
    while True:
        y = sum_proper_divisors(m)
        if m != y and sum_proper_divisors(y) == m:
            return m
        m += 1

# Test cases
print("Enter the numbers:")
numbers = input().split()
print("The output is: ")
for number in numbers:
    result = amc(int(number) if number.isdigit() else number)
    print(result)
