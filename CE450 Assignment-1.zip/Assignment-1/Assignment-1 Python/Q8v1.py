def double_5(n):
    n_str = str(n)
    for i in range(len(n_str) - 1):
        if n_str[i] == '5' and n_str[i + 1] == '5':
            return True
    return False

n = input("Enter a number: ")

try:
    n = int(n)
    result = double_5(n)
    print("The output is:", result)
except ValueError:
    print("Invalid input. Please enter an integer.")
