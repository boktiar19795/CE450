def if_function(condition, true_result, false_result):
    try:
        if eval(condition):
            return eval(true_result)
        else:
            return eval(false_result)
    except:
        return false_result

condition = input("Enter the condition: ")
true_result = input("Enter the true result: ")
false_result = input("Enter the false result: ")

result = if_function(condition, true_result, false_result)
print("Result:", result)
