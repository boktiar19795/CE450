def pfct_num(n):
    if n <= 0:
        return False
    factors_sum = sum(i for i in range(1, abs(n)) if n % i == 0)
    return factors_sum == abs(n)


def get_input_value(prompt):
    while True:
        try:
            value = int(input(prompt))
            return value
        except ValueError:
            print("Please enter a valid integer.")


n = get_input_value("Enter an integer: ")

result = pfct_num(n)

print("The output is:", result)
