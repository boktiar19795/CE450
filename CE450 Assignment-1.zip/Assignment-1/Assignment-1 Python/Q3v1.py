def foo(a, b, c, d):
    numbers = [a, b, c, d]
    numbers.sort(key=lambda x: abs(x))
    smallest1 = numbers[0]
    smallest2 = numbers[1]
    return smallest1 ** 2 + smallest2 ** 2


def get_input_value(prompt):
    while True:
        try:
            value = int(input(prompt))
            return value
        except ValueError:
            print("Please enter a valid integer.")


a = get_input_value("Enter the value of 'a': ")
b = get_input_value("Enter the value of 'b': ")
c = get_input_value("Enter the value of 'c': ")
d = get_input_value("Enter the value of 'd': ")

result = foo(a, b, c, d)

print("The output is:", result)
