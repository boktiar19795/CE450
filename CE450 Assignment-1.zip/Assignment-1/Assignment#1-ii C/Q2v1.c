#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void bubbleSort(int arr[], int n) {
    int i, j, tem;
    
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                tem = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tem;
            }
        }
    }
}

void printSortedNum(int arr[], int n) {
    int i, oddInd = 0, evenInd = 0;
    int oddAr[n], evenAr[n];

    for (i = 0; i < n; i++) {
        if (arr[i] % 2 == 0) {
            evenAr[evenInd++] = arr[i];
        } else {
            oddAr[oddInd++] = arr[i];
        }
    }

    printf("After sorting, output sequence: ");
    for (i = 0; i < oddInd; i++) {
        printf("%d ", oddAr[i]);
    }
    for (i = 0; i < evenInd; i++) {
        printf("%d ", evenAr[i]);
    }
    printf("\n");
}

int main() {
    int n, i;

    printf("Enter a number of array’s size for a series of numbers saving: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input\n");
        return 0;
    }

    if (n <= 0) {
        printf("Invalid input\n");
        return 0;
    }

    int arr[n];

    printf("Enter a series of %d numbers: ", n);
    for (i = 0; i < n; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            printf("Invalid input\n");
            return 0;
        }
    }

    bubbleSort(arr, n);
    printSortedNum(arr, n);

    return 0;
}
