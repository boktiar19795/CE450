#include <stdio.h>

#define MAX_DISHES 100

int main() 
{
    int numDishes;
    int original[MAX_DISHES];
    int new[MAX_DISHES];
    float reproductionRate[MAX_DISHES];

    printf("Enter total number of Petri dishes: ");
    scanf("%d", &numDishes);

    printf("Enter Petri dish label, original bacterial number, new bacterial number\n");
    printf("after one hour reproduction:\n");

    for (int i = 0; i < numDishes; i++)
    {
        printf("Dish %d: ", i + 1);
        scanf("%*s %d %d", &original[i], &new[i]);

        reproductionRate[i] = (float)new[i] / original[i];
    }

    int maxIndex = 0;
    for (int i = 1; i < numDishes; i++) 
    {
        if (reproductionRate[i] > reproductionRate[maxIndex]) 
        {
            maxIndex = i;
        }
    }

   
    float threshold = reproductionRate[maxIndex] * 0.99; 

    printf("\nResults:\n");
    for (int i = 0; i < numDishes; i++) 
    {
        if (reproductionRate[i] >= threshold) 
        {
            printf("Dish %d: Sub-species A\n", i + 1);
        } else {
            printf("Dish %d: Sub-species B\n", i + 1);
        }
    }

    return 0;
}