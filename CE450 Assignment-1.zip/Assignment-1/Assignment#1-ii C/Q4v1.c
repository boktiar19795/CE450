#include <stdio.h>

int main() {
    int num_of_decimal, one_Num = 0;

    printf("Enter decimal number: ");
    if (scanf("%d", &num_of_decimal) != 1) {
        printf("Invalid input\n");
        return 0;
    }

    unsigned int unsigned_decimal = (unsigned int)num_of_decimal;

    while (unsigned_decimal) {
        if (unsigned_decimal & 1) {
            one_Num++;
        }
        unsigned_decimal >>= 1;
    }
    
    printf("There are %d ones in the given decimal number\n", one_Num);

    return 0;
}
