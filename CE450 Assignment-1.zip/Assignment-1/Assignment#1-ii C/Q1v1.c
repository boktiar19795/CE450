#include <stdio.h>
#include <stdlib.h> // Include the <stdlib.h> header for the atoi() function

void bubbleSort(int arr[], int n) {
    int i, j, tem;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                tem = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tem;
            }
        }
    }
}

int main() {
    int n, i;

    printf("Enter a number of array’s size for a series of numbers saving: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid Input\n");
        return 0;
    }

    int arr[n];

    printf("Enter a series of %d numbers: ", n);
    for (i = 0; i < n; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            printf("Invalid Input\n");
            return 0;
        }
    }

    bubbleSort(arr, n);

    printf("\nAfter sorting, the output sequence is: ");
    for (i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}
