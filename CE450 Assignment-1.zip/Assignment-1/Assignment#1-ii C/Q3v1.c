#include <stdio.h>
#include <stdbool.h>

int calpiece(int cut) {
    int piece = 1;

    while (cut > 0) {
        piece += cut;
        cut--;
    }

    return piece;
}

int main() {
    int n;

    printf("Enter how many cuts you want: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input\n");
        return 0;
    }

    if (n < 0) {
        printf("Invalid input\n");
        return 0;
    }

    int piece = calpiece(n);

    printf("For %d Pieces, the number of cuts will be: %d\n", n, piece);

    return 0;
}
